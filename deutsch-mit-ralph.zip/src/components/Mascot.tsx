export function Mascot({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" aria-hidden="true">
      <ellipse cx="50" cy="92" rx="24" ry="5" fill="rgba(0,0,0,.12)" />
      <circle cx="30" cy="30" r="12" fill="#B07B4F" /><circle cx="70" cy="30" r="12" fill="#B07B4F" />
      <circle cx="30" cy="30" r="6" fill="#D8A26A" /><circle cx="70" cy="30" r="6" fill="#D8A26A" />
      <circle cx="50" cy="52" r="34" fill="#C88A50" /><circle cx="50" cy="60" r="20" fill="#EAC79A" />
      <circle cx="40" cy="46" r="5" fill="#3A3140" /><circle cx="60" cy="46" r="5" fill="#3A3140" />
      <circle cx="41.5" cy="44.5" r="1.6" fill="#fff" /><circle cx="61.5" cy="44.5" r="1.6" fill="#fff" />
      <ellipse cx="50" cy="56" rx="4" ry="3" fill="#3A3140" />
      <path d="M42 64 Q50 70 58 64" stroke="#3A3140" strokeWidth="2.4" fill="none" strokeLinecap="round" />
    </svg>
  );
}
